(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// collection/collection.js                                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
var imagesPath = "/home/pi/ESE-519-Project/bin/images";                // 1
var imageStore = new FS.Store.FileSystem("images", { path: imagesPath });
                                                                       //
Images = new FS.Collection("images", {                                 // 4
  stores: [imageStore]                                                 // 5
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=collection.js.map
