(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/server.js                                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
var exec = Npm.require('child_process').exec;                          // 1
//FS.debug = true;                                                     //
//var sudo = Npm.require('sudo');                                      //
var projPath = "/home/pi/ESE-519-Project/bin";                         // 4
                                                                       //
Meteor.methods({                                                       // 6
  'playGIF': function (fileName, duration_ms) {                        // 7
    var imgPath = projPath + "/images/" + fileName;                    // 8
    var execPath = projPath + "/playGIF";                              // 9
    var command = execPath + " " + imgPath + " " + duration_ms;        // 10
    exec(command, function (error, stdout, stderr) {                   // 11
      //console.log("stdout: " + stdout);                              //
      //console.log("stderr: " + stderr);                              //
      if (error !== null) {                                            // 14
        console.log("exec error: " + error);                           // 15
      }                                                                //
    });                                                                //
  }                                                                    //
});                                                                    //
                                                                       //
Images.allow({                                                         // 21
  insert: function () {                                                // 22
    return true;                                                       // 23
  },                                                                   //
  update: function () {                                                // 25
    return false;                                                      // 26
  },                                                                   //
  remove: function () {                                                // 28
    return false;                                                      // 29
  },                                                                   //
  download: function () {                                              // 31
    return false;                                                      // 32
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=server.js.map
